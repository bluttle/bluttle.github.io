# Animated Search Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexpopovich/pen/PWLRgV](https://codepen.io/alexpopovich/pen/PWLRgV).

