# Animated Search Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/aqib-hanief/pen/dwBQdy](https://codepen.io/aqib-hanief/pen/dwBQdy).

Animated Search Box using Html, Css and jQuery